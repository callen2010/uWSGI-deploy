For details on how to use these files please watch

http://sysadmincasts.com/episodes/5-create-a-vagrant-box-with-veewee

Thanks,
Justin

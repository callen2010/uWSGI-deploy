# Install Chef
gem install --no-ri --no-rdoc chef

